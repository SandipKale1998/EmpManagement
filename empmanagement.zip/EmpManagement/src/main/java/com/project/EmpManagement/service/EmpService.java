package com.project.EmpManagement.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.EmpManagement.entity.Employee;
import com.project.EmpManagement.repository.EmpRepo;

@Service
public class EmpService {
	@Autowired //this is use to create object automatically
	private EmpRepo repo;
	public void addemp(Employee e) {
		 
		repo.save(e); // save() method is use to insert data in database 
		
	}
	
	// to display all employee list  in home page 
	public List<Employee> getAllEmp(){
		return repo.findAll();
		
	}
	
	public Employee getEmpById(int id) {
		Optional<Employee> e= repo.findById(id);
		if(e.isPresent()) { // write this because null pointer exception are not get
			return e.get();
		}
		return null;
	}
	
	// use to delete empdata on system 
	public void deleteEmp(int id) {
		repo.deleteById(id);
	}

}
// wee use devtool for auto run  , table creation  and others  may be 
